/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.proyecto_1_ipc1.main.mejoras;

/**
 *
 * @author DELL
 */
public class Vida extends Mejora {
    
    public Vida() {
        nombre = "Vida";
        aumento = 50;
        precio = 80;
    }
}
